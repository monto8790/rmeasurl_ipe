# water_data_models
Water domain data models and examples in JSON-LD
